# densa Design System

**densa** is a multi-tenant SaaS platform for clinics and dental practices — covering CRM, appointment scheduling, inbox (email), team management, and admin tools. The interface is written in Romanian.

- **Source repo:** `Freq95/m-saas` (private, Next.js 16 App Router + TypeScript + MongoDB)
- **Deployment:** Vercel
- **Design tokens:** `styles/theme.css` (canonical source), consumed by `app/globals.css`

---

## Products / Surfaces

| Surface | Description |
|---------|-------------|
| **Web App** | Primary SaaS interface — dashboard, calendar, clients CRM, inbox, settings |
| **Auth Pages** | Login, forgot password, invite accept, reset password |
| **Admin Panel** | Super-admin tenant/user management, audit logs |
| **PWA** | Installable on Android Chrome and iOS Safari |

---

## CONTENT FUNDAMENTALS

### Language
All UI copy is in **Romanian** (`ro-RO` locale). Dates use `date-fns` with the `ro` locale. Error messages and form labels are in Romanian.

### Tone & Voice
- **Minimal and direct** — labels are short, imperative or noun-form. No filler words.
- **Professional, not clinical** — warm enough for a clinic context without being casual.
- **Second-person ("tu")** — the UI addresses the user directly (e.g., *"Sigur vrei să te deconectezi?"*).
- **Casing:** Sentence case everywhere (not Title Case). Example: *"Adaugă client"*, *"Ultima vizită"*.
- **No emoji** — the product is emoji-free. Status is communicated via colored badges, not emoji.
- **Abbreviations avoided** — dates spell out month names (e.g., *"12 apr. 2026"*).

### Copy Examples
- "Adaugă client" (not "Add New Client")
- "Ultima vizită: 03 apr. 2026"
- "Nu există programări pentru astăzi"
- "Sigur vrei să te deconectezi din cont?"
- "Rata no-show", "Total cheltuit", "Clienti noi (săptămâna)"

---

## VISUAL FOUNDATIONS

### Color
- **Default theme: dark** — near-black background (`#06080d`), glassmorphism surfaces with `backdrop-filter: blur(14px)`.
- **Light theme:** off-white background (`#f0f4f8`), white surfaces. Toggled via `[data-theme="light"]` attribute.
- **Accent:** Electric blue — `#4da3ff` (dark) / `#2563eb` (light). Used for CTAs, active nav indicator, bar charts, focus rings.
- **Text hierarchy:** three levels — `--color-text` (primary `#e6edf8`), `--color-text-muted` (`#9fb0cb`), `--color-text-soft` (`#7f93b2`).
- **Semantic palette:** success (green), warning (amber), danger (red), info (blue), neutral (slate) — each has text/bg/border triples.
- **No decorative gradients on content** — the only gradient is the subtle radial app background and the accent bar fill.

### Typography
- **UI font: Satoshi** — weights 300–800. Used for all body, labels, headings, inputs.
- **Brand font: Chillax** — used exclusively for the "densa" wordmark; `letter-spacing: -0.03em`.
- **Mono font: JetBrains Mono / Fira Code** — for code/timestamps where tabular numerals matter.
- **Base size: 15px** (`--text-base: 0.9375rem`). Scale: 12/13/15/16/18/22/28px.
- **Letter spacing:** Headings use `letter-spacing: -0.02em` to `-0.03em`. Labels use `0.01em`.
- **Font smoothing:** `-webkit-font-smoothing: antialiased` everywhere.

### Backgrounds & Surfaces
- App background: layered radial gradients + linear gradient — deep navy near-black.
- Surfaces: `rgba` with glassmorphism blur (`backdrop-filter: blur(14px)`).
- Cards: `--color-surface` (64% opacity navy), border `rgba(148,163,184,0.2)`, `border-radius: 18px`, `box-shadow: var(--shadow-sm)`.
- No full-bleed imagery, no background photos, no hand-drawn illustrations, no texture.

### Spacing
- 4px base unit, scale: 4/8/12/16/20/24/32/40/48/64px.
- Content max-width: 1240px, centered with `margin-inline: auto`.

### Corner Radii
- `--radius-xs: 8px` — small UI chips
- `--radius-sm: 10px` — icon buttons, small controls
- `--radius-md: 14px` — inputs, buttons, modals
- `--radius-lg: 18px` — cards, panels, large containers
- `--radius-pill: 999px` — badges, nav indicator

### Shadows & Elevation
- Three levels: sm (`6px 18px` dark), md (`14px 34px`), lg (`24px 48px`).
- Light theme shadows are lighter and less opaque.
- No colored/glow shadows except subtle accent glow on chart bars.

### Animation & Motion
- **Easing: `ease-out`** for all transitions (fast: 200ms, base: 300ms).
- **Nav indicator:** slides using `cubic-bezier(0.2, 0.9, 0.2, 1)` over 560ms — elastic feel.
- **Route transition:** fade + translateY(8px) + blur(1px) in 380ms using `cubic-bezier(0.22, 1, 0.36, 1)`.
- **Hover cards:** `translateY(-1px)` or `translateY(-2px)` on hover.
- **Press state:** `scale(0.97)` on `:active`.
- **Skeleton shimmer:** translateX sweep 1.25s ease-in-out infinite.
- **No bounce, no spring, no parallax** — professional and restrained.
- `prefers-reduced-motion` respected everywhere.

### Interactive States
- **Hover:** slightly brighter surface + stronger border; icon buttons get surface fill.
- **Focus:** double-ring focus outline — dark inner ring + blue accent outer ring.
- **Disabled:** `opacity: 0.42`, `cursor: not-allowed`.
- **Active/press:** `scale(0.97)` transform.

### Borders
- Default: `1px solid rgba(148,163,184,0.2)` — very subtle.
- Strong: `rgba(148,163,184,0.3)` — on hover or elevated elements.
- No border-only accent (no left-border cards).

### Transparency & Blur
- Glassmorphism is central: nav bar, cards, modals all use `backdrop-filter: blur(14px)`.
- Modal overlay: `color-mix(in srgb, --color-bg 76%, transparent)` + blur(8px).
- Never on decorative elements — blur is structural.

### Imagery
- No photography in the product. No illustrations. No icons beyond inline SVG strokes.
- PWA icons exist at 192×192 and 512×512 (PNG).

### Iconography
See ICONOGRAPHY section below.

---

## ICONOGRAPHY

- **No icon library** — all icons are **inline SVG** drawn directly in TSX components.
- **Style:** stroke-based, `strokeWidth="2"`, `strokeLinecap="round"`, `strokeLinejoin="round"` — matching Lucide/Heroicons style.
- **Size:** consistently 16×16px in nav and buttons; larger contextually.
- **Color:** inherits `currentColor` — adapts to theme automatically.
- **No icon font, no sprite sheet, no CDN icon library referenced.**
- **No emoji used as icons anywhere.**
- Common icons used: sun/moon (theme toggle), gear (settings), power (logout), chevrons, search, plus, calendar glyphs.

Assets copied: `assets/icon-192.png`, `assets/icon-512.png` (PWA app icons).

---

## Files

| Path | Contents |
|------|----------|
| `README.md` | This file — design system overview |
| `colors_and_type.css` | All CSS custom properties: colors, type, spacing, shape, elevation |
| `fonts/satoshi/` | Satoshi woff2 files (Light, Regular, Medium, Bold, Black) |
| `fonts/chillax/` | Chillax woff2 files (Regular, Medium, Semibold, Bold) |
| `assets/icon-192.png` | PWA app icon 192×192 |
| `assets/icon-512.png` | PWA app icon 512×512 |
| `preview/` | Design system preview cards (registered in Design System tab) |
| `ui_kits/app/` | densa web app UI kit — clickable prototype |
| `SKILL.md` | Agent skill definition |
