// densa — Clients CRM Screen Component

const clientsStyles = `
  .dn-clients { padding: 28px 24px 48px; width: min(100%, 1240px); margin: 0 auto; }
  .dn-clients-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; flex-wrap: wrap; gap: 12px; }
  .dn-clients-title { font-size: 1.5rem; font-weight: 700; letter-spacing: -0.03em; color: #e6edf8; }
  .dn-filters-bar { background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2); border-radius: 18px; padding: 14px 18px; margin-bottom: 16px; display: flex; gap: 10px; flex-wrap: wrap; align-items: center; backdrop-filter: blur(14px); }
  .dn-search { flex: 1; min-width: 200px; height: 38px; background: rgba(30,41,59,0.45); border: 1px solid rgba(148,163,184,0.2); border-radius: 12px; color: #e6edf8; font-size: 0.875rem; font-family: inherit; padding: 0 12px 0 36px; outline: none; }
  .dn-search-wrap { position: relative; flex: 1; min-width: 200px; display: flex; align-items: center; }
  .dn-search-icon { position: absolute; left: 12px; color: #7f93b2; pointer-events: none; display: flex; }
  .dn-select { height: 38px; background: rgba(30,41,59,0.45); border: 1px solid rgba(148,163,184,0.2); border-radius: 12px; color: #e6edf8; font-size: 0.8125rem; font-family: inherit; padding: 0 12px; outline: none; cursor: pointer; }
  .dn-btn-add { display: inline-flex; align-items: center; gap: 6px; height: 38px; padding: 0 18px; background: #4da3ff; color: #fff; border: 1px solid #4da3ff; border-radius: 12px; font-size: 0.8125rem; font-weight: 600; cursor: pointer; white-space: nowrap; transition: background 200ms; }
  .dn-btn-add:hover { background: #2d88ff; }
  .dn-btn-ghost { display: inline-flex; align-items: center; height: 38px; padding: 0 14px; background: rgba(30,41,59,0.45); color: #9fb0cb; border: 1px solid rgba(148,163,184,0.2); border-radius: 12px; font-size: 0.8125rem; cursor: pointer; transition: background 200ms; }
  .dn-btn-ghost:hover { background: rgba(17,24,39,0.64); color: #e6edf8; }
  .dn-table-wrap { background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2); border-radius: 18px; backdrop-filter: blur(14px); overflow: hidden; box-shadow: 0 6px 18px rgba(2,7,18,0.24); }
  .dn-table { width: 100%; border-collapse: collapse; font-size: 0.875rem; }
  .dn-table thead tr { border-bottom: 1px solid rgba(148,163,184,0.2); }
  .dn-table th { text-align: left; padding: 12px 16px; font-size: 0.75rem; font-weight: 500; color: #9fb0cb; letter-spacing: 0.02em; white-space: nowrap; }
  .dn-table td { padding: 12px 16px; color: #e6edf8; border-bottom: 1px solid rgba(148,163,184,0.1); vertical-align: middle; }
  .dn-table tr:last-child td { border-bottom: none; }
  .dn-table tbody tr { cursor: pointer; transition: background 150ms; }
  .dn-table tbody tr:hover { background: rgba(30,41,59,0.45); }
  .dn-client-name-cell { font-weight: 600; color: #e6edf8; }
  .dn-contact-cell { display: flex; flex-direction: column; gap: 2px; }
  .dn-contact-cell .email { font-size: 0.8125rem; color: #9fb0cb; }
  .dn-contact-cell .phone { font-size: 0.8125rem; color: #7f93b2; }
  .dn-amount { font-weight: 600; font-variant-numeric: tabular-nums; }
  .dn-gdpr-ok { color: #34d399; font-weight: 600; }
  .dn-gdpr-no { color: #f87171; font-weight: 600; }
  .dn-pagination { display: flex; align-items: center; justify-content: center; gap: 12px; padding: 16px; border-top: 1px solid rgba(148,163,184,0.2); }
  .dn-pag-btn { height: 34px; padding: 0 14px; background: rgba(30,41,59,0.45); border: 1px solid rgba(148,163,184,0.2); border-radius: 10px; color: #9fb0cb; font-size: 0.8125rem; cursor: pointer; transition: background 200ms; }
  .dn-pag-btn:hover:not(:disabled) { background: rgba(17,24,39,0.64); color: #e6edf8; }
  .dn-pag-btn:disabled { opacity: 0.4; cursor: not-allowed; }
  .dn-pag-info { font-size: 0.8125rem; color: #7f93b2; }
`;

const SAMPLE_CLIENTS = [
  { id:1, name: 'Andreea Lungu', email: 'andreea@email.ro', phone: '0721 234 567', spent: 1240, apts: 8, lastVisit: '18 apr. 2026', gdpr: true },
  { id:2, name: 'Mihai Popescu', email: 'mihai.p@gmail.com', phone: '0744 123 456', spent: 980, apts: 6, lastVisit: '12 apr. 2026', gdpr: true },
  { id:3, name: 'Elena Dobre', email: 'elena@dobre.ro', phone: null, spent: 760, apts: 5, lastVisit: '05 apr. 2026', gdpr: false },
  { id:4, name: 'Radu Constantin', email: 'radu.c@yahoo.com', phone: '0756 345 678', spent: 320, apts: 3, lastVisit: '10 feb. 2026', gdpr: true },
  { id:5, name: 'Ioana Vlad', email: null, phone: '0768 901 234', spent: 120, apts: 2, lastVisit: '22 ian. 2026', gdpr: false },
  { id:6, name: 'Dan Mureșan', email: 'dan.m@firma.ro', phone: '0733 456 789', spent: 0, apts: 0, lastVisit: 'Niciodată', gdpr: false },
  { id:7, name: 'Maria Dumitrescu', email: 'maria.d@gmail.com', phone: '0721 999 001', spent: 450, apts: 4, lastVisit: '20 apr. 2026', gdpr: true },
  { id:8, name: 'Bogdan Florescu', email: 'bogdan@email.com', phone: '0744 888 002', spent: 200, apts: 2, lastVisit: '15 apr. 2026', gdpr: true },
];

function ClientsScreen({ onNavigate }) {
  const [search, setSearch] = React.useState('');
  const filtered = SAMPLE_CLIENTS.filter(c =>
    c.name.toLowerCase().includes(search.toLowerCase()) ||
    (c.email || '').toLowerCase().includes(search.toLowerCase())
  );

  return (
    <>
      <style>{clientsStyles}</style>
      <div className="dn-clients">
        <div className="dn-clients-header">
          <div className="dn-clients-title">Clienți</div>
        </div>
        <div className="dn-filters-bar">
          <div className="dn-search-wrap">
            <span className="dn-search-icon">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
            </span>
            <input className="dn-search" placeholder="Caută după nume, email sau telefon" value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="dn-select">
            <option>Ultima activitate (recent)</option>
            <option>Total cheltuit (mare)</option>
            <option>Nume (A–Z)</option>
          </select>
          <select className="dn-select">
            <option>Toate (GDPR)</option>
            <option>Cu consimțământ</option>
            <option>Fără consimțământ</option>
          </select>
          <button className="dn-btn-ghost">Export CSV</button>
          <button className="dn-btn-add">+ Adaugă client</button>
        </div>
        <div className="dn-table-wrap">
          <table className="dn-table">
            <thead>
              <tr>
                <th>Nume</th><th>Contact</th><th>Total cheltuit</th>
                <th>Programări</th><th>Ultima vizită</th><th>GDPR</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(c => (
                <tr key={c.id} onClick={() => onNavigate('client-detail')}>
                  <td><span className="dn-client-name-cell">{c.name}</span></td>
                  <td>
                    <div className="dn-contact-cell">
                      {c.email && <span className="email">{c.email}</span>}
                      {c.phone && <span className="phone">{c.phone}</span>}
                      {!c.email && !c.phone && <span style={{color:'#7f93b2',fontSize:'0.8rem'}}>Fără contact</span>}
                    </div>
                  </td>
                  <td><span className="dn-amount">{c.spent.toLocaleString('ro-RO')} RON</span></td>
                  <td>{c.apts}</td>
                  <td style={{color:'#9fb0cb',fontSize:'0.8125rem'}}>{c.lastVisit}</td>
                  <td>{c.gdpr ? <span className="dn-gdpr-ok">✓</span> : <span className="dn-gdpr-no">✗</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="dn-pagination">
            <button className="dn-pag-btn" disabled>Anterior</button>
            <span className="dn-pag-info">Pagina 1 din 1 ({filtered.length} total)</span>
            <button className="dn-pag-btn" disabled>Următor</button>
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { ClientsScreen });
