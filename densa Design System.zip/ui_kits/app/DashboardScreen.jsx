// densa — Dashboard Screen Component

const dashboardStyles = `
  .dn-dashboard { padding: 32px 24px 48px; width: min(100%, 1240px); margin: 0 auto; }
  .dn-page-label { font-size: 0.75rem; font-weight: 500; color: #7f93b2; letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 20px; }
  .dn-stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 14px; margin-bottom: 28px; }
  .dn-stat-card {
    background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2);
    border-radius: 18px; padding: 20px 24px; backdrop-filter: blur(14px);
    box-shadow: 0 6px 18px rgba(2,7,18,0.24);
    transition: transform 200ms ease-out, border-color 200ms, box-shadow 200ms;
    cursor: default;
  }
  .dn-stat-card:hover { transform: translateY(-2px); border-color: rgba(148,163,184,0.3); box-shadow: 0 14px 34px rgba(2,7,18,0.35); }
  .dn-stat-label { font-size: 0.78rem; color: #9fb0cb; font-weight: 500; letter-spacing: 0.01em; margin-bottom: 8px; }
  .dn-stat-value { font-size: 1.85rem; font-weight: 700; color: #e6edf8; letter-spacing: -0.03em; }
  .dn-stat-delta { font-size: 0.75rem; margin-top: 4px; font-weight: 500; }
  .dn-stat-delta.pos { color: #34d399; }
  .dn-stat-delta.neg { color: #f87171; }
  .dn-charts { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 16px; margin-bottom: 28px; }
  .dn-chart-card {
    background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2);
    border-radius: 18px; padding: 22px; backdrop-filter: blur(14px); box-shadow: 0 6px 18px rgba(2,7,18,0.24);
  }
  .dn-chart-title { font-size: 0.92rem; font-weight: 650; color: #e6edf8; letter-spacing: -0.01em; margin-bottom: 18px; }
  .dn-bar-chart { display: flex; align-items: flex-end; gap: 8px; height: 140px; }
  .dn-bar-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 5px; height: 100%; justify-content: flex-end; }
  .dn-bar-val { font-size: 0.72rem; color: #9fb0cb; font-weight: 500; }
  .dn-bar-track { flex: 1; width: 100%; display: flex; align-items: flex-end; min-height: 20px; }
  .dn-bar-fill { width: 100%; background: linear-gradient(135deg,#1b63db,#4da3ff); border-radius: 7px 7px 4px 4px; min-height: 4px; box-shadow: 0 0 0 1px rgba(77,163,255,0.2), 0 8px 18px rgba(27,99,219,0.2); }
  .dn-bar-lbl { font-size: 0.68rem; color: #7f93b2; text-align: center; }
  .dn-client-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(min(260px,100%), 1fr)); gap: 14px; }
  .dn-client-card { background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2); border-radius: 18px; padding: 20px; backdrop-filter: blur(14px); box-shadow: 0 6px 18px rgba(2,7,18,0.24); }
  .dn-client-card h4 { font-size: 0.92rem; font-weight: 650; color: #e6edf8; margin-bottom: 14px; letter-spacing: -0.01em; }
  .dn-client-item { display: flex; flex-direction: column; gap: 3px; padding: 10px 12px; border: 1px solid rgba(148,163,184,0.2); background: rgba(30,41,59,0.45); border-radius: 12px; margin-bottom: 6px; cursor: pointer; transition: border-color 200ms, background 200ms, transform 200ms; text-decoration: none; }
  .dn-client-item:hover { border-color: rgba(148,163,184,0.3); background: rgba(17,24,39,0.64); transform: translateY(-1px); }
  .dn-client-name { font-size: 0.88rem; font-weight: 600; color: #e6edf8; }
  .dn-client-meta { font-size: 0.74rem; color: #7f93b2; display: flex; gap: 10px; }
  .dn-apt-item { display: flex; align-items: center; gap: 14px; padding: 10px 12px; background: rgba(30,41,59,0.45); border: 1px solid rgba(148,163,184,0.2); border-radius: 12px; margin-bottom: 6px; transition: background 200ms, border-color 200ms; }
  .dn-apt-item:hover { background: rgba(17,24,39,0.64); border-color: rgba(148,163,184,0.3); }
  .dn-apt-time { min-width: 80px; display: flex; gap: 4px; align-items: center; font-variant-numeric: tabular-nums; }
  .dn-apt-time span { font-size: 0.88rem; font-weight: 600; color: #e6edf8; }
  .dn-apt-time .sep { font-weight: 400; color: #7f93b2; font-size: 0.78rem; }
  .dn-apt-details { flex: 1; min-width: 0; }
  .dn-apt-client { font-size: 0.88rem; font-weight: 600; color: #e6edf8; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .dn-apt-service { font-size: 0.76rem; color: #7f93b2; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .dn-status { display: inline-flex; align-items: center; border-radius: 999px; border: 1px solid; font-size: 0.7rem; font-weight: 600; padding: 3px 9px; white-space: nowrap; }
  .dn-status.scheduled { background: rgba(148,163,184,0.1); color: #9fb0cb; border-color: rgba(148,163,184,0.18); }
  .dn-status.completed { background: rgba(52,211,153,0.12); color: #34d399; border-color: rgba(52,211,153,0.22); }
  .dn-status.cancelled { background: rgba(245,158,11,0.12); color: #fbbf24; border-color: rgba(245,158,11,0.28); }
  .dn-status.noshow { background: rgba(248,113,113,0.12); color: #f87171; border-color: rgba(248,113,113,0.22); }
`;

const CHART_DATA = [
  { label: 'Lu', count: 5 }, { label: 'Ma', count: 8 }, { label: 'Mi', count: 3 },
  { label: 'Jo', count: 11 }, { label: 'Vi', count: 7 }, { label: 'Sâ', count: 2 }, { label: 'Du', count: 9 },
];
const MAX_COUNT = Math.max(...CHART_DATA.map(d => d.count));

const APPOINTMENTS = [
  { time: '09:00', end: '09:30', client: 'Andreea Lungu', service: 'Detartraj', status: 'completed' },
  { time: '10:15', end: '11:00', client: 'Mihai Popescu', service: 'Implant consult', status: 'scheduled' },
  { time: '12:00', end: '12:30', client: 'Diana Ionescu', service: 'Albire dentară', status: 'scheduled' },
  { time: '14:30', end: '15:00', client: 'Radu Constantin', service: 'Control periodic', status: 'noshow' },
];

const STATUS_LABELS = { scheduled: 'Programat', completed: 'Finalizat', cancelled: 'Anulat', noshow: 'Absent' };

function DashboardScreen({ onNavigate }) {
  return (
    <>
      <style>{dashboardStyles}</style>
      <div className="dn-dashboard">
        <div className="dn-stats-grid">
          {[
            { label: 'Mesaje astăzi', value: '14', delta: '+3 față de ieri', dir: 'pos' },
            { label: 'Programări astăzi', value: '8', delta: null },
            { label: 'Total clienți', value: '348', delta: '+12 săptămâna asta', dir: 'pos' },
            { label: 'Clienți noi (săpt.)', value: '12', delta: null },
            { label: 'Rata no-show', value: '4%', delta: '-1% față de luna trecută', dir: 'pos' },
          ].map((s, i) => (
            <div className="dn-stat-card" key={i}>
              <div className="dn-stat-label">{s.label}</div>
              <div className="dn-stat-value">{s.value}</div>
              {s.delta && <div className={`dn-stat-delta ${s.dir}`}>{s.delta}</div>}
            </div>
          ))}
        </div>

        <div className="dn-charts">
          <div className="dn-chart-card">
            <div className="dn-chart-title">Programări — ultimele 7 zile</div>
            <div className="dn-bar-chart">
              {CHART_DATA.map((d, i) => (
                <div className="dn-bar-item" key={i}>
                  <div className="dn-bar-val">{d.count}</div>
                  <div className="dn-bar-track">
                    <div className="dn-bar-fill" style={{ height: `${(d.count / MAX_COUNT) * 100}%` }} />
                  </div>
                  <div className="dn-bar-lbl">{d.label}</div>
                </div>
              ))}
            </div>
          </div>
          <div className="dn-chart-card">
            <div className="dn-chart-title">Creștere clienți — 7 zile</div>
            <div className="dn-bar-chart">
              {[2,5,3,8,4,6,12].map((c, i) => (
                <div className="dn-bar-item" key={i}>
                  <div className="dn-bar-val">{c}</div>
                  <div className="dn-bar-track">
                    <div className="dn-bar-fill" style={{ height: `${(c / 12) * 100}%`, background: 'linear-gradient(135deg,#0d9488,#34d399)' }} />
                  </div>
                  <div className="dn-bar-lbl">{['Lu','Ma','Mi','Jo','Vi','Sâ','Du'][i]}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="dn-client-grid">
          <div className="dn-client-card">
            <h4>Top Clienți</h4>
            {[['Andreea Lungu','1.240 lei','8 programări'],['Mihai Popescu','980 lei','6 programări'],['Elena Dobre','760 lei','5 programări']].map(([n,s,a],i) => (
              <div className="dn-client-item" key={i} onClick={() => onNavigate('clients')}>
                <div className="dn-client-name">{n}</div>
                <div className="dn-client-meta"><span>{s}</span><span>{a}</span></div>
              </div>
            ))}
          </div>
          <div className="dn-client-card">
            <h4>Clienți Inactivi (30+ zile)</h4>
            {[['Radu Constantin','Ultima vizită: 10 feb. 2026'],['Ioana Vlad','Ultima vizită: 22 ian. 2026'],['Dan Mureșan','Fără programări recente']].map(([n,m],i) => (
              <div className="dn-client-item" key={i} onClick={() => onNavigate('clients')}>
                <div className="dn-client-name">{n}</div>
                <div className="dn-client-meta"><span>{m}</span></div>
              </div>
            ))}
          </div>
          <div className="dn-client-card">
            <h4>Programări astăzi</h4>
            {APPOINTMENTS.map((a, i) => (
              <div className="dn-apt-item" key={i}>
                <div className="dn-apt-time">
                  <span>{a.time}</span><span className="sep">–</span><span>{a.end}</span>
                </div>
                <div className="dn-apt-details">
                  <div className="dn-apt-client">{a.client}</div>
                  <div className="dn-apt-service">{a.service}</div>
                </div>
                <span className={`dn-status ${a.status}`}>{STATUS_LABELS[a.status]}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { DashboardScreen });
