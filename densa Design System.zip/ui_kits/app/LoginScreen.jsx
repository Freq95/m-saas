// densa — Login Screen Component

const loginStyles = `
  .dn-login-page { min-height: 100vh; display: grid; place-items: center; padding: 24px; background: var(--gradient-app); }
  .dn-login-box { width: 100%; max-width: 420px; }
  .dn-login-wordmark { font-family: 'Chillax', sans-serif; font-size: 1.9rem; font-weight: 700; color: #e6edf8; letter-spacing: -0.03em; margin-bottom: 28px; }
  .dn-login-card { background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2); border-radius: 18px; padding: 28px; backdrop-filter: blur(14px); box-shadow: 0 14px 34px rgba(2,7,18,0.35); }
  .dn-login-title { font-size: 1.15rem; font-weight: 600; color: #e6edf8; margin-bottom: 22px; letter-spacing: -0.01em; }
  .dn-field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
  .dn-field label { font-size: 0.8125rem; font-weight: 500; color: #9fb0cb; }
  .dn-field input { height: 42px; background: rgba(30,41,59,0.45); border: 1px solid rgba(148,163,184,0.2); border-radius: 12px; color: #e6edf8; font-size: 0.9375rem; font-family: inherit; padding: 0 14px; outline: none; transition: border-color 200ms, box-shadow 200ms; }
  .dn-field input:focus { border-color: #4da3ff; box-shadow: 0 0 0 2px rgba(6,8,13,0.9), 0 0 0 4px rgba(77,163,255,0.5); }
  .dn-forgot { display: block; color: #60a5fa; font-size: 0.8125rem; margin-bottom: 20px; text-decoration: none; cursor: pointer; }
  .dn-forgot:hover { color: #4da3ff; }
  .dn-btn-login { width: 100%; height: 42px; background: #4da3ff; color: #fff; border: 1px solid #4da3ff; border-radius: 12px; font-size: 0.9375rem; font-weight: 600; cursor: pointer; transition: background 200ms; }
  .dn-btn-login:hover { background: #2d88ff; }
  .dn-login-footer { display: flex; justify-content: center; gap: 20px; margin-top: 22px; }
  .dn-login-footer a { font-size: 0.78rem; color: #7f93b2; text-decoration: none; cursor: pointer; }
  .dn-login-footer a:hover { color: #9fb0cb; }
  .dn-error { font-size: 0.8125rem; color: #f87171; margin-bottom: 12px; padding: 8px 12px; background: rgba(248,113,113,0.1); border: 1px solid rgba(248,113,113,0.22); border-radius: 10px; }
`;

function LoginScreen({ onLogin }) {
  const [email, setEmail] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [error, setError] = React.useState(null);
  const [loading, setLoading] = React.useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!email || !password) { setError('Completați toate câmpurile.'); return; }
    setLoading(true);
    setError(null);
    setTimeout(() => { setLoading(false); onLogin(); }, 800);
  };

  return (
    <>
      <style>{loginStyles}</style>
      <div className="dn-login-page">
        <div className="dn-login-box">
          <div className="dn-login-wordmark">densa</div>
          <div className="dn-login-card">
            <div className="dn-login-title">Conectează-te</div>
            {error && <div className="dn-error">{error}</div>}
            <form onSubmit={handleSubmit}>
              <div className="dn-field">
                <label>Email</label>
                <input type="email" placeholder="email@clinica.ro" value={email} onChange={e => setEmail(e.target.value)} />
              </div>
              <div className="dn-field">
                <label>Parolă</label>
                <input type="password" placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
              </div>
              <a className="dn-forgot">Ai uitat parola?</a>
              <button type="submit" className="dn-btn-login" disabled={loading}>
                {loading ? 'Se conectează…' : 'Conectează-te'}
              </button>
            </form>
            <div className="dn-login-footer">
              <a>Politica de confidențialitate</a>
              <a>Termeni și condiții</a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { LoginScreen });
