# densa App UI Kit

Interactive click-through prototype of the densa web application.

## Screens

| Screen | Description |
|--------|-------------|
| **Login** | Auth form — email + password, forgot password link, legal footer |
| **Dashboard** | Stats grid, bar charts (appointments + client growth), top clients, inactive clients, today's appointments |
| **Calendar** | Week view with appointment blocks, day headers, nav controls |
| **Clients** | CRM table with search/filter/sort, GDPR column, pagination |
| **Client Detail** | Individual client card with stats (stub) |
| **Inbox / Settings** | Placeholder — not included in kit |

## Components

| File | Contents |
|------|----------|
| `TopNav.jsx` | Fixed top nav with animated underline indicator, icon buttons, logout modal trigger |
| `DashboardScreen.jsx` | Stat cards, bar charts, client/appointment lists |
| `ClientsScreen.jsx` | Filterable CRM table, search input, sort/filter selects |
| `CalendarScreen.jsx` | Week grid with absolutely positioned appointment blocks |
| `LoginScreen.jsx` | Centered auth form with error state |

## Usage

Open `index.html` in a browser. Use the **Tweaks** panel (toolbar toggle) to:
- Switch dark/light theme
- Jump between screens
