// densa — Calendar Screen Component

const calendarStyles = `
  .dn-calendar { padding: 24px; width: min(100%, 1240px); margin: 0 auto; }
  .dn-cal-header { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; flex-wrap: wrap; }
  .dn-cal-title { font-size: 1.5rem; font-weight: 700; letter-spacing: -0.03em; color: #e6edf8; flex: 1; }
  .dn-cal-nav { display: flex; align-items: center; gap: 6px; }
  .dn-cal-nav-btn { display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:10px;border:1px solid rgba(148,163,184,0.2);background:transparent;color:#9fb0cb;cursor:pointer;transition:background 200ms,color 200ms; }
  .dn-cal-nav-btn:hover { background:rgba(30,41,59,0.45);color:#e6edf8; }
  .dn-cal-today-btn { height:34px;padding:0 14px;border-radius:10px;border:1px solid rgba(148,163,184,0.2);background:transparent;color:#9fb0cb;font-size:0.8125rem;cursor:pointer;transition:background 200ms,color 200ms; }
  .dn-cal-today-btn:hover { background:rgba(30,41,59,0.45);color:#e6edf8; }
  .dn-btn-new-apt { display:inline-flex;align-items:center;gap:6px;height:36px;padding:0 16px;background:#4da3ff;color:#fff;border:1px solid #4da3ff;border-radius:12px;font-size:0.8125rem;font-weight:600;cursor:pointer;transition:background 200ms; }
  .dn-btn-new-apt:hover { background:#2d88ff; }
  .dn-week-grid { background: rgba(17,24,39,0.64); border: 1px solid rgba(148,163,184,0.2); border-radius: 18px; overflow: hidden; backdrop-filter: blur(14px); box-shadow: 0 6px 18px rgba(2,7,18,0.24); }
  .dn-week-head { display: grid; grid-template-columns: 56px repeat(7, 1fr); border-bottom: 1px solid rgba(148,163,184,0.2); }
  .dn-week-head-cell { padding: 10px 8px; text-align: center; font-size: 0.75rem; font-weight: 500; color: #9fb0cb; }
  .dn-week-head-cell .day-num { font-size: 1.1rem; font-weight: 700; color: #e6edf8; display: block; margin-top: 2px; }
  .dn-week-head-cell.today .day-num { color: #f97316; }
  .dn-week-body { display: grid; grid-template-columns: 56px repeat(7, 1fr); height: 400px; overflow-y: auto; }
  .dn-time-col { border-right: 1px solid rgba(148,163,184,0.2); }
  .dn-time-slot { height: 50px; padding: 0 6px; display: flex; align-items: flex-start; padding-top: 4px; font-size: 0.68rem; color: #7f93b2; font-variant-numeric: tabular-nums; border-bottom: 1px solid rgba(148,163,184,0.08); }
  .dn-day-col { position: relative; border-right: 1px solid rgba(148,163,184,0.1); }
  .dn-day-col:last-child { border-right: none; }
  .dn-day-slot { height: 50px; border-bottom: 1px solid rgba(148,163,184,0.08); cursor: pointer; transition: background 150ms; }
  .dn-day-slot:hover { background: rgba(77,163,255,0.04); }
  .dn-apt-block { position: absolute; left: 3px; right: 3px; border-radius: 8px; padding: 5px 7px; overflow: hidden; cursor: pointer; transition: filter 200ms; }
  .dn-apt-block:hover { filter: brightness(1.15); }
  .dn-apt-block .aname { font-size: 0.72rem; font-weight: 600; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
  .dn-apt-block .atime { font-size: 0.65rem; color: rgba(255,255,255,0.75); }
`;

const DAYS = ['Luni', 'Marți', 'Miercuri', 'Joi', 'Vineri', 'Sâmbătă', 'Duminică'];
const DAY_NUMS = [21, 22, 23, 24, 25, 26, 27];
const HOURS = Array.from({ length: 10 }, (_, i) => `${i + 8}:00`);

const APT_BLOCKS = [
  { day: 0, startSlot: 1, duration: 1, client: 'Andreea Lungu', service: 'Detartraj', color: '#1b63db' },
  { day: 1, startSlot: 2, duration: 2, client: 'Mihai Popescu', service: 'Implant consult', color: '#0d9488' },
  { day: 1, startSlot: 5, duration: 1, client: 'Elena Dobre', service: 'Albire', color: '#7c3aed' },
  { day: 3, startSlot: 0, duration: 1, client: 'Maria Dumitrescu', service: 'Control', color: '#1b63db' },
  { day: 3, startSlot: 3, duration: 2, client: 'Radu Constantin', service: 'Proteză', color: '#b45309' },
  { day: 4, startSlot: 1, duration: 1, client: 'Dan Mureșan', service: 'Rx panoramic', color: '#0d9488' },
];

function CalendarScreen({ onNavigate }) {
  return (
    <>
      <style>{calendarStyles}</style>
      <div className="dn-calendar">
        <div className="dn-cal-header">
          <div className="dn-cal-title">21 – 27 Aprilie 2026</div>
          <div className="dn-cal-nav">
            <button className="dn-cal-nav-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg></button>
            <button className="dn-cal-today-btn">Azi</button>
            <button className="dn-cal-nav-btn"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg></button>
          </div>
          <button className="dn-btn-new-apt">+ Programare nouă</button>
        </div>

        <div className="dn-week-grid">
          <div className="dn-week-head">
            <div className="dn-week-head-cell"></div>
            {DAYS.map((d, i) => (
              <div key={i} className={`dn-week-head-cell${i === 1 ? ' today' : ''}`}>
                {d}
                <span className="day-num">{DAY_NUMS[i]}</span>
              </div>
            ))}
          </div>
          <div className="dn-week-body">
            <div className="dn-time-col">
              {HOURS.map(h => <div key={h} className="dn-time-slot">{h}</div>)}
            </div>
            {DAYS.map((d, di) => (
              <div key={di} className="dn-day-col">
                {HOURS.map((h, hi) => <div key={hi} className="dn-day-slot" />)}
                {APT_BLOCKS.filter(a => a.day === di).map((a, ai) => (
                  <div key={ai} className="dn-apt-block"
                    style={{ top: a.startSlot * 50 + 2, height: a.duration * 50 - 4, background: a.color }}>
                    <div className="aname">{a.client}</div>
                    <div className="atime">{a.service}</div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}

Object.assign(window, { CalendarScreen });
