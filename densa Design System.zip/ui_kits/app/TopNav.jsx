// densa — Top Navigation Component
// Fixed bar: wordmark + nav links with animated underline indicator + icon buttons

const TopNavStyles = `
  .dn-nav {
    position: fixed; top: 0; left: 0; right: 0; z-index: 120;
    background: rgba(13, 18, 30, 0.78); border-bottom: 1px solid rgba(148,163,184,0.2);
    padding: 0 24px; height: 56px;
    display: flex; justify-content: space-between; align-items: center; gap: 16px;
    backdrop-filter: blur(14px); -webkit-backdrop-filter: blur(14px);
  }
  .dn-logo {
    font-family: 'Chillax', sans-serif; font-size: 1.12rem; font-weight: 700;
    color: #e6edf8; letter-spacing: -0.02em; cursor: pointer; user-select: none;
    text-decoration: none;
  }
  .dn-links { position: relative; display: flex; align-items: center; gap: 24px; }
  .dn-link {
    color: #7f93b2; font-size: 0.9375rem; text-decoration: none; cursor: pointer;
    transition: color 200ms ease; white-space: nowrap; padding: 0;
    background: none; border: none; font-family: inherit;
  }
  .dn-link:hover { color: #e6edf8; }
  .dn-link.active { color: #e6edf8; }
  .dn-indicator {
    position: absolute; bottom: -18px; height: 2px; border-radius: 999px;
    background: linear-gradient(135deg, #1b63db, #4da3ff);
    transition: transform 560ms cubic-bezier(0.2, 0.9, 0.2, 1), width 560ms cubic-bezier(0.2, 0.9, 0.2, 1);
    pointer-events: none;
  }
  .dn-right { display: flex; align-items: center; gap: 6px; flex-shrink: 0; }
  .dn-icon-btn {
    display: inline-flex; align-items: center; justify-content: center;
    width: 34px; height: 34px; border-radius: 10px;
    border: 1px solid rgba(148,163,184,0.2); background: transparent;
    color: #7f93b2; cursor: pointer;
    transition: color 200ms, background 200ms, border-color 200ms;
  }
  .dn-icon-btn:hover { color: #e6edf8; background: rgba(30,41,59,0.45); border-color: rgba(148,163,184,0.3); }
  .dn-icon-btn.danger:hover { color: #f87171; background: rgba(248,113,113,0.12); border-color: rgba(248,113,113,0.22); }
`;

function TopNav({ active, onNavigate, onLogout }) {
  const navItems = [
    { key: 'dashboard', label: 'Dashboard' },
    { key: 'inbox',     label: 'Inbox' },
    { key: 'calendar',  label: 'Calendar' },
    { key: 'clients',   label: 'Clienți' },
  ];
  const linksRef = React.useRef(null);
  const [indicator, setIndicator] = React.useState({ x: 0, w: 0 });

  React.useEffect(() => {
    const container = linksRef.current;
    if (!container) return;
    const el = container.querySelector(`[data-key="${active}"]`);
    if (!el) return;
    const cr = container.getBoundingClientRect();
    const er = el.getBoundingClientRect();
    setIndicator({ x: er.left - cr.left, w: er.width });
  }, [active]);

  return (
    <>
      <style>{TopNavStyles}</style>
      <nav className="dn-nav">
        <span className="dn-logo" onClick={() => onNavigate('dashboard')}>densa</span>
        <div className="dn-links" ref={linksRef}>
          {navItems.map(item => (
            <button key={item.key} data-key={item.key}
              className={`dn-link${active === item.key ? ' active' : ''}`}
              onClick={() => onNavigate(item.key)}>
              {item.label}
            </button>
          ))}
          <span className="dn-indicator" style={{ width: indicator.w, transform: `translateX(${indicator.x}px)` }} />
        </div>
        <div className="dn-right">
          <button className="dn-icon-btn" title="Schimbă tema">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
          </button>
          <button className="dn-icon-btn" title="Setări" onClick={() => onNavigate('settings')}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
          </button>
          <button className="dn-icon-btn danger" title="Deconectare" onClick={onLogout}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/></svg>
          </button>
        </div>
      </nav>
    </>
  );
}

Object.assign(window, { TopNav });
